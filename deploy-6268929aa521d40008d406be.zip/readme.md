# Capstone
Group 181 Capstone Project 
Project on a responsive web page 
Members 
1.@osesanmiolajide (SH-IT-0004912)
2.@bassey.utibe22 (SH-IT-0005300)
3.@berrypurity5 (SH-IT-0005492)
4.@jenkincbenaiah (SH-IT-0012453)
5.@adekoyatobaa(SH-IT-0023346)
6.@ivydogun16 (SH-IT-0047483)
7.@edidiongimohh (SH-IT-0048910)
8.@Chidubemotiji (SH-IT-0054713)
9.@fatimahbalogun (SH-IT-0000881) Team Lead

Contribution
All team members contributed to the
codes development and the styling 
of the page on it been responsive.

